/*****************************************************************************
 JEP - Java Math Expression Parser 2.24
      December 30 2002
      (c) Copyright 2002, Nathan Funk
      See LICENSE.txt for license information.

 *****************************************************************************/
package edu.iastate.utils.jep;

import java.util.Hashtable;

public class FunctionTable
    extends Hashtable
{
    public FunctionTable()
    {

    }
}
