package edu.iastate.utils.lang;



/**
 * Interface for class that handle message
 * @author Jie Bao
 * @since 1.0
 */
public interface MessageHandler
{
    public void messageMap();
}
