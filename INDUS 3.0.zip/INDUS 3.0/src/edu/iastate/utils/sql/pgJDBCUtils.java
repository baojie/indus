package edu.iastate.utils.sql;

/**
 * PostGreSQL JDBC utils
 * @author Jie Bao
 * @since 1.0 2005-02-22
 */
public class pgJDBCUtils
    extends JDBCUtils
{

}
