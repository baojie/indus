package edu.iastate.anthill.indus;

import edu.iastate.utils.log.Config;

/**
 * @author Jie Bao
 * @since 1.0 2005-03-11
 */
public class IndusConfig
    extends Config
{
    public IndusConfig(String configFileName)
    {
        super(configFileName, false);
    }

    protected void createNew()
    {
    }

    protected void objToXML(Object obj)
    {
    }

    protected void xmlToObj(Object obj)
    {
    }

}
