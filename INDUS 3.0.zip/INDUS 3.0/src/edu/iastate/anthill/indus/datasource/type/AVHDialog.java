package edu.iastate.anthill.indus.datasource.type;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

import edu.iastate.anthill.indus.tree.TypedTree;

import edu.iastate.utils.Debug;

/**
 * A dialog to visualize an AVH tree
 * <p>@author Jie Bao , baojie@cs.iastate.edu</p>
 * <p>@since 2005-03-27</p>
 *
 */
public class AVHDialog
    extends JDialog
{
    JPanel panel1 = new JPanel();

    AVH myAVH;

    BorderLayout borderLayout2 = new BorderLayout();
    JButton btnCancel = new JButton();
    JButton btnOK = new JButton();

    public AVHDialog(AVH avh, Object defaultValue, JFrame frame)
    {
        super(frame, "AVH Dialog", true);

        this.myAVH = avh;
        this.selectedValue = defaultValue;

        try
        {
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            jbInit();
            pack();
        }
        catch (Exception exception)
        {
            exception.printStackTrace();
        }
    }

    private void jbInit() throws Exception
    {
        this.getContentPane().setLayout(borderLayout2);
        btnCancel.setToolTipText("");
        btnCancel.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                onCancel(e);
            }
        });
        btnOK.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                onOK(e);
            }
        });

        // set default selection
        //Debug.trace(myAVH);

        TypedTree tree = myAVH.getTreeAVH();
        tree.selectFirst(selectedValue);

        JPanel treeEditor = myAVH.getEditorPane();
        this.getContentPane().add(new JScrollPane(treeEditor),
                                  java.awt.BorderLayout.CENTER);
        btnCancel.setText("Cancel");
        this.getContentPane().add(panel1, java.awt.BorderLayout.SOUTH);
        btnOK.setText("OK");
        panel1.add(btnOK, null);
        panel1.add(btnCancel, null);

        this.pack();
    }

    public boolean isOK = false;
    public Object selectedValue;

    public void onCancel(ActionEvent e)
    {
        isOK = false;
        dispose();
    }

    public void onOK(ActionEvent e)
    {
        isOK = true;
        TreePath path = myAVH.getTreeAVH().getSelectionPath();
        if (path != null)
        {
            DefaultMutableTreeNode node = (DefaultMutableTreeNode) path.
                getLastPathComponent();
            selectedValue = node.getUserObject();
        }
        dispose();
    }

    // for test
    public static void main(String[] args)
    {
        AVH avh = new AVH("Test Tree", "ISA");
        TypedTree tree = new TypedTree();
        tree.buildSampleTree();
        avh.setTree(tree);

        //Debug.trace(avh.getTreeAVH().toString());

        AVHDialog dlg = new AVHDialog(
            avh, "http://semanticWWW.com/indus.owl#Iowa", null);
        dlg.setSize(800, 600);
        dlg.show();

        if (dlg.isOK)
        {
            Debug.trace("Click OK, selected value = " + dlg.selectedValue);
        }
        else
        {
            Debug.trace("The dialog is cancelled");
        }

    }
}
