package edu.iastate.anthill.indus.datasource.type;

import edu.iastate.anthill.indus.IndusBasis;

import edu.iastate.utils.Debug;

/**
 * @author Jie Bao
 * @since 2005-04-01
 */
public class AVHTest
{
    public static void main(String[] args)
    {
        AVH avh = new AVH("Test", "ISA");
        avh.treeAVT.buildSampleTree();

        System.out.println(avh.treeAVT.toString());

        String xml = avh.toXML();
        //System.out.println(SimpleXMLParser.printXMLSkeleton(xml));
        IndusBasis.showXML(xml);

        AVH avh1 = new AVH();
        avh1.fromXML(xml);
        IndusBasis.showXML(avh1.toXML());
        Debug.pause();
    }
}
