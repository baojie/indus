package edu.iastate.anthill.indus.iterator.mapping;

/**
 * @author Jie Bao
 * @since 2005-04-08
 */
public interface MappingDB
{
    public void loadToDB();
    public boolean createTable();
}
