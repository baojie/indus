package edu.iastate.ato;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.tree.TreePath;

import edu.iastate.anthill.indus.IndusConstants;
import edu.iastate.anthill.indus.datasource.type.DbAVHEditor;
import edu.iastate.anthill.indus.tree.TypedNode;

import edu.iastate.utils.undo.EditingAction;

/**
 * Animal Trait Ontology Tree Editor
 * @author Jie Bao
 * @since 2005-04-22
 */

public class ATOTreeEditor
    extends DbAVHEditor
{

    public ATOTreeEditor(AtoOntology avh, ATOEditor fatherPanel)
    {
        super(null, avh);
        this.fatherPanel = fatherPanel;
    }

    public static ImageIcon iconProperty = IndusConstants.loadImageIcon(
        "details.gif");

    protected void buildContextMenu(TypedNode selectedNode)
    {
        ATOTreeNode atoNode = (ATOTreeNode) selectedNode;
        if (atoNode.status == ATOTreeNode.DELETED)
        {
            String label = "Undelete " + atoNode;
            addMenuItem(label, IndusConstants.iconUndo,
                        new UndeleteAction(atoNode));

            return;
        }

        super.buildContextMenu(selectedNode);

    }

    // 2005-04-24
    protected class UndeleteAction
        implements ActionListener
    {
        ATOTreeNode theNode;

        public UndeleteAction(ATOTreeNode atoNode)
        {
            this.theNode = atoNode;
        }

        public void actionPerformed(ActionEvent e)
        {
            ATOTreeNodeUnDeleteEditing action = new ATOTreeNodeUnDeleteEditing(
                theNode);
            Enumeration<ATOTreeNode> en = theNode.breadthFirstEnumeration();
            while (en.hasMoreElements())
            {
                ATOTreeNode node = en.nextElement();
                node.status = ATOTreeNode.MODIFIED;
                action.addNode(node);
            }
            changed(theNode);
            theNode.status = ATOTreeNode.MODIFIED;
            history.addAction(action);
        }
    }

    // show node details
    public void mouseClicked(MouseEvent e)
    {
        TreePath selPath = tree.getPathForLocation(e.getX(), e.getY());
        if (selPath != null)
        {
            tree.setSelectionPath(selPath);

            final ATOTreeNode selectedNode = (ATOTreeNode)
                selPath.getLastPathComponent();

            if(selectedNode.status == ATOTreeNode.DELETED)
            {
                return;
            }

            super.mouseClicked(e);
            if (e.getClickCount() == 1)
            {

                JPanel paneDetails = ( (ATOEditor)this.fatherPanel).paneDetails;

                paneDetails.removeAll();
                paneDetails.add(new DetailsPane(selectedNode, (AtoOntology) avh));
                paneDetails.revalidate();
                paneDetails.repaint();

            }
        }
    }

    protected String makeDefaultName(TypedNode selected)
    {
        String localId = selected.getUserObject().toString();

        AtoOntology ato = (AtoOntology) avh;
        ATO2Tree db2tree = (ATO2Tree) ato.templateTree;
        Vector<String> child = db2tree.getChildren(localId);
        // read database
        int max = -1;
        for (String id : child)
        {
            int seg = lastSeg(id);
            max = Math.max(max, seg);
        }
        // read gui
        for (int i = 0; i < selected.getChildCount(); i++)
        {
            TypedNode kid = (TypedNode) selected.getChildAt(i);
            String id = kid.getUserObject().toString();
            int seg = lastSeg(id);
            max = Math.max(max, seg);
        }

        return localId + "-" + (max + 1);
    }

    int lastSeg(String id)
    {
        int idx = id.lastIndexOf("-");
        String str = id;
        if (idx != -1)
        {
            str = id.substring(idx + 1);
        }
        return Integer.parseInt(str);
    }

    protected TypedNode makeNewNode(TypedNode theNode) throws HeadlessException
    {
        String newName = JOptionPane.showInputDialog(
            "Give the ID for new node", makeDefaultName(theNode));
        if (newName == null)
        {
            return null;
        }
        short level = AtoOntology.getNextLevelDomain(theNode.getType());
        String comment = AtoOntology.getDomainStr(level);

        ATOTreeNode newNode = new ATOTreeNode(newName, comment, level);
        newNode.status = ATOTreeNode.MODIFIED;

        return newNode;
    }

    protected void changed(TypedNode theNode)
    {
        if (theNode != null)
        {
            super.changed(theNode);

            ATOEditor parent = (ATOEditor)this.fatherPanel;

            //update details pane
            if (theNode instanceof ATOTreeNode)
            {
                JPanel paneDetails = parent.paneDetails;
                paneDetails.removeAll();
                paneDetails.add(new DetailsPane( (ATOTreeNode) theNode,
                                                (AtoOntology) avh));
                paneDetails.revalidate();
                paneDetails.repaint();

                // make it modified
                ( (ATOTreeNode) theNode).status = ATOTreeNode.MODIFIED;
            }

            // update toolbar
            parent.btnUndo.setEnabled(history.canUndo());
            parent.btnRedo.setEnabled(history.canRedo());
        }
    }

    protected void delete(TypedNode theNode)
    {
        ATOTreeNodeDeleteEditing action = new ATOTreeNodeDeleteEditing(
            theNode);

        Enumeration<ATOTreeNode> e = theNode.breadthFirstEnumeration();
        while (e.hasMoreElements())
        {
            ATOTreeNode node = e.nextElement();
            action.addNode(node);
            node.status = ATOTreeNode.DELETED;
        }
        //tree.getModel().removeNodeFromParent(theNode);
        changed(theNode);
        ( (ATOTreeNode) theNode).status = ATOTreeNode.DELETED;
        //changed(parent);

        history.addAction(action);

    }

    protected void deleteAllChildren(TypedNode theNode)
    {
        ATOTreeNodeDeleteEditing action = new ATOTreeNodeDeleteEditing(
            theNode);

        short oldStatus = ( (ATOTreeNode) theNode).status;
        Enumeration<ATOTreeNode> e = theNode.breadthFirstEnumeration();

        while (e.hasMoreElements())
        {
            ATOTreeNode node = e.nextElement();
            action.addNode(node);
            node.status = ATOTreeNode.DELETED;
        }
        //tree.getModel().removeNodeFromParent(theNode);
        changed(theNode);
        ( (ATOTreeNode) theNode).status = oldStatus;
        //changed(parent);

        history.addAction(action);
    }

    class ATOTreeNodeDeleteEditing
        extends EditingAction
    {
        Map<ATOTreeNode, Short> oldStatus = new HashMap();

        public ATOTreeNodeDeleteEditing(TypedNode theNode)
        {
            location = theNode;
            this.summary = "Delete subtree below '" + location;
        }

        public void addNode(ATOTreeNode node)
        {
            oldStatus.put(node, node.status);
        }

        public void undo()
        {
            for (ATOTreeNode node : oldStatus.keySet())
            {
                node.status = oldStatus.get(node);
            }
            tree.repaint();
        }

        public void redo()
        {
            for (ATOTreeNode node : oldStatus.keySet())
            {
                node.status = ATOTreeNode.DELETED;
            }
            tree.repaint();

        }
    }

    class ATOTreeNodeUnDeleteEditing
        extends EditingAction
    {
        Set<ATOTreeNode> nodes = new HashSet();

        public ATOTreeNodeUnDeleteEditing(TypedNode theNode)
        {
            location = theNode;
            this.summary = "Undelete subtree below '" + location;
        }

        public void addNode(ATOTreeNode node)
        {
            nodes.add(node);
        }

        public void undo()
        {
            for (ATOTreeNode node : nodes)
            {
                node.status = ATOTreeNode.DELETED;
            }
            tree.repaint();
        }

        public void redo()
        {
            for (ATOTreeNode node : nodes)
            {
                node.status = ATOTreeNode.MODIFIED;
            }
            tree.repaint();
        }
    }
}
