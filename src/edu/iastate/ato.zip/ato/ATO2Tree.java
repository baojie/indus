package edu.iastate.ato;

import java.sql.Connection;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JScrollPane;

import edu.iastate.anthill.indus.iterator.DB2Tree;
import edu.iastate.anthill.indus.iterator.DBTreeNode;
import edu.iastate.anthill.indus.tree.TypedTree;

import edu.iastate.utils.Debug;
import edu.iastate.utils.sql.LocalDBConnection;

/**
 * Animal Trait Ontology
 *
 * @author Jie Bao
 * @since 2005-04-20
 */
public class ATO2Tree
    extends DB2Tree
{
    public ATO2Tree(Connection db)
    {
        super(db);
    }

    public String findComments(String id)
    {
        return defaultFindComments("term", "id", "name", id);
    }

    protected String findDomain(String id)
    {
        return defaultFindComments("term", "id", "domain", id);
    }

    public Vector getChildren(String from_id)
    {
        return defaultGetChildren("relation", "id", "pid",
                                  from_id, null, null);
    }

    public Vector getParent(String from_id)
    {
        return defaultGetParent("relation", "id", "pid",
                                from_id, null, null);
    }

    public String getRootId()
    {
        return "0"; // our meta root for ATO
    }

    public DBTreeNode createNode(String id)
    {
        //System.out.println("ATO2Tree.createNode() :" + id);
        String domain = findDomain(id);
        String descrption = findComments(id);
        short type = AtoOntology.getDomain(domain);
        //Debug.trace("'"+domain+"' "+ type);
        return new ATOTreeNode(id, descrption, type);
    }

    public Trait getTraitDetails(String id)
    {
        Trait trait = new Trait();
        trait.id = id;
        trait.name = defaultFindComments("term", "id", "name", id);
        trait.abbr = defaultFindComments("trait", "trait_id", "abbreviat", id);
        trait.customName = defaultFindComments("trait", "trait_id",
                                               "custom_name", id);
        trait.traitDesc = defaultFindComments("trait", "trait_id", "trait_desc",
                                              id);
        trait.measurement = defaultFindComments("trait", "trait_id",
                                                "measurement", id);
        trait.scaleUnit = defaultFindComments("trait", "trait_id", "scale_unit",
                                              id);
        return trait;
    }

    /**
     * For test purpose
     * @param args String[]
     */
    public static void main(String[] args)
    {
        LocalDBConnection conn = ATOEditor.getConnection();
        if (conn.connect())
        {
            ATO2Tree mm = new ATO2Tree(conn.db);
            TypedTree t = mm.getTree(null, -1);
            conn.disconnect();

            // show it
            JFrame frame = new JFrame();
            frame.setSize(800, 600);
            JScrollPane scr = new JScrollPane(t);
            frame.getContentPane().add(scr);
            frame.setVisible(true);
            System.out.print(t);
        }
        else
        {
            Debug.trace("Cannot connect to database");
        }
    }

}
