package edu.iastate.ato;

import java.util.prefs.Preferences;

import java.awt.event.ActionEvent;
import javax.swing.JButton;

import edu.iastate.utils.lang.MessageHandler;
import edu.iastate.utils.lang.MessageMap;
import edu.iastate.utils.sql.JDBCConfigPanel;

/**
 * JDBC Setting
 *
 * @author Jie Bao
 * @since 2005-04-20
 */
public class SettingPanel
    extends JDBCConfigPanel implements MessageHandler
{
    Preferences prefs = Preferences.userNodeForPackage(SettingPanel.class);
    protected JButton btnSave = new JButton("Save Setting");

    public SettingPanel()
    {
        try
        {
            jbInit();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    protected void jbInit() throws Exception
    {
        messageMap();

        DBMachineURL.setText(prefs.get("url", "jdbc:postgresql://boole.cs.iastate.edu/ato"));
        UserID.setText(prefs.get("user", "ato"));
        UserPwd.setText(prefs.get("passwd", "ato"));
        jdbcDriver.setText(prefs.get("driver", "org.postgresql.Driver"));
        DBType.setSelectedItem(prefs.get("type", "POSTGRE"));

        paneButton.add(btnSave, null);

        super.jbInit();
    }

    public void messageMap()
    {
        try
        {
            MessageMap.mapAction(this.btnTest, this, "onTest");
            MessageMap.mapAction(this.btnSave, this, "onSave");
        }
        catch (Exception ex)
        {
        }
    }

    public void onSave(ActionEvent evt)
    {
        prefs.put("url", DBMachineURL.getText());
        prefs.put("user", UserID.getText());
        prefs.put("passwd", new String(UserPwd.getPassword()));
        prefs.put("driver", jdbcDriver.getText());
        prefs.put("type", (String) DBType.getSelectedItem());
    }
}
