package edu.iastate.ato.po;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import edu.iastate.ato.ATOEditor;

import edu.iastate.utils.sql.JDBCUtils;
import edu.iastate.utils.sql.LocalDBConnection;

/**
 * <p>@author Jie Bao</p>
 * <p>@since 2005-06-07</p>
 */
public class DbModularOntology
    extends ModularOntology implements AtoConstent
{
    Connection db;

    public DbModularOntology()
    {
        LocalDBConnection ds = ATOEditor.getConnection();
        ds.connect();
        db = ds.db;
    }

    public static void main(String[] args)
    {
        DbModularOntology dmo = new DbModularOntology();
        //dmo.addPackage("p1");
        //dmo.addPackage("p2");
        //dmo.removePackage("p1");
        dmo.addPackageRelation("p1", "import", "p2");
        dmo.addPackageRelation("p2", "in", "p3");
        dmo.removePackageRelation("p1", "import", "p2");
        dmo.getAllPackages();
        System.out.println(dmo.getTopLevelPackage());
    }

    // 2005-06-13
    Vector getAllPackages()
    {
        String sql = "SELECT pid FROM " + packageTable;
        Vector v = new Vector<String> ();

        try
        {
            Statement stmt = db.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next())
            {
                v.add(rs.getString(1));
            }
        }
        catch (SQLException ex)
        {
            return null;
        }
        System.out.println(v);

        return v;
    }

    boolean isVisible(String term, String pkg)
    {
        String sql = "SELECT slm FROM " + termTable + " WHERE id = '" +
            term + "'";
        String slm = JDBCUtils.getValue(db, sql);
        sql = "SELECT package FROM " + termTable + " WHERE id = '" +
            term + "'";
        String hp = JDBCUtils.getValue(db, sql);

        // public term: visible from anywhere
        if (Package.PUBLIC.equals(slm))
        {
            return true;
        }
        // private term: visible from home package
        else if (Package.PRIVATE.equals(slm))
        {
            return pkg.equals(hp);
        }
        // protected term: visible from nested-in packages
        else if (Package.PROTECTED.equals(slm))
        {
            return isNestedIn(hp, pkg) || pkg.equals(hp);
        }
        return false;
    }

    boolean isNestedIn(String pkg1, String pkg2)
    {
        String father = getFatherPackage(pkg1);
        while (father != null)
        {
            if (father.equals(pkg2))
            {
                return true;
            }
            father = getFatherPackage(father);
        }
        return false;
    }

    Vector getTopLevelPackage()
    {
        String sql = "SELECT pid FROM package WHERE pid NOT IN ( " +
            " SELECT p1 FROM pkg_relation WHERE relation = '"+
            NESTED_IN + "' AND p2 IS NOT NULL);";
        return JDBCUtils.getValues(db,sql);
    }

    String getFatherPackage(String pkg)
    {
        String sql = "SELECT p2 FROM " + relationTable + " WHERE p1 = '" +
            pkg + "'";
        String father = JDBCUtils.getValue(db, sql);
        return father;
    }

    boolean addPackage(String pid)
    {
        String sql = "INSERT INTO " + packageTable + " (pid)  VALUES ('" + pid +
            "');";
        return JDBCUtils.updateDatabase(db, sql);
    }

    void addPackageRelation(String p1, String r, String p2)
    {
        Map m = new HashMap();
        m.put("p1", p1);
        m.put("relation", r);
        m.put("p2", p2);
        JDBCUtils.insertDatabase(db, relationTable, m);
    }

    void removePackageRelation(String p1, String r, String p2)
    {
        String sql = "DELETE FROM " + relationTable +
            " WHERE p1 = '" + p1 + "' AND " +
            " p2 = '" + p2 + "' AND " +
            " relation = '" + r + "';";
        JDBCUtils.updateDatabase(db, sql);
    }

    void removePackage(String pid)
    {
        // remove the package
        String sql = "DELETE FROM " + packageTable + " WHERE pid = '" + pid +
            "';";
        JDBCUtils.updateDatabase(db, sql);

        // remove the package relations
        sql = "DELETE FROM " + relationTable + " WHERE p1 = '" + pid + "';";
        JDBCUtils.updateDatabase(db, sql);

        // remove all terms in the package
        sql = "DELETE FROM " + termTable + " WHERE package = '" + pid + "';";
        JDBCUtils.updateDatabase(db, sql);
    }

    void moveTerm(String term, String pkg1, String pkg2)
    {
        String sql = "UPDATE " + termTable +
            " SET package = '" + pkg2 + "' WHERE id = '" + term + "';";
        JDBCUtils.updateDatabase(db, sql);
    }

}
