package edu.iastate.ato.po;

/**
 * <p>@author Jie Bao</p>
 * <p>@since 2005-06-07</p>
 */
public class ModularOntology
{

    public static final String IMPORT = "import", NESTED_IN = "nested_in";

    public static void main(String[] args)
    {
        ModularOntology modularontology = new ModularOntology();
    }
}
