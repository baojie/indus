package edu.iastate.ato.po;

/**
 * <p>@author Jie Bao</p>
 * <p>@since 2005-06-13</p>
 */
public interface AtoConstent
{
    public String packageTable = "package";
    public String relationTable = "pkg_relation";
    public String termTable = "term";

}
