package edu.iastate.ato.po;

/**
 * <p>@author Jie Bao</p>
 * <p>@since 2005-06-07</p>
 */
public class Package
{
    public static final String PUBLIC = "public", PROTECTED = "protected",
        PRIVATE = "private";

    public static void main(String[] args)
    {
        Package p = new Package();
    }
}
