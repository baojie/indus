package edu.iastate.ato.po;

import java.sql.Connection;
import edu.iastate.ato.ATOEditor;
import edu.iastate.utils.sql.LocalDBConnection;
import edu.iastate.utils.sql.JDBCUtils;
import java.util.Map;
import java.util.HashMap;
import java.util.Vector;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

/**
 * <p>@author Jie Bao</p>
 * <p>@since 2005-06-07</p>
 */
public class DbPackage
    extends Package implements AtoConstent
{
    Connection db;
    String pkgName;

    public DbPackage(String name)
    {
        LocalDBConnection ds = ATOEditor.getConnection();
        ds.connect();
        this.db = ds.db;
        this.pkgName = name;
    }

    boolean isPackageExist()
    {
        return JDBCUtils.getCount(db, this.packageTable,
                                  "pid='" + pkgName + "'") > 0;
    }

    void addTerm(String id, String name, String slm)
    {
        Map m = new HashMap();
        m.put("id", id);
        m.put("name", name);
        m.put("package", pkgName);
        m.put("slm", slm);
        JDBCUtils.insertDatabase(db, termTable, m);
    }

    Vector getVisibleTerms()
    {
        String sql = "SELECT id FROM " + termTable + " WHERE slm = '" +
            PUBLIC + "'";
        Vector v = new Vector<String> ();

        try
        {
            Statement stmt = db.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next())
            {
                v.add(rs.getString(1));
            }
        }
        catch (SQLException ex)
        {
            return null;
        }
        System.out.println(v);

        return v;

    }

    Vector getAllTerms()
    {
        String sql = "SELECT id FROM " + termTable;
        Vector v = new Vector<String> ();

        try
        {
            Statement stmt = db.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next())
            {
                v.add(rs.getString(1));
            }
        }
        catch (SQLException ex)
        {
            return null;
        }
        System.out.println(v);

        return v;

    }

    public static void main(String[] args)
    {
        DbPackage p1 = new DbPackage("p1");
        System.out.println(p1.isPackageExist());
        p1.addTerm("000", "t1", PUBLIC);
        System.out.println(p1.getAllTerms());

    }

}
