package edu.iastate.ato;

import java.io.IOException;
import java.util.Enumeration;
import java.util.prefs.Preferences;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

import edu.iastate.anthill.indus.AboutBoxDialog;
import edu.iastate.anthill.indus.datasource.type.AVHEditor;
import edu.iastate.anthill.indus.tree.TypedTree;

import edu.iastate.utils.Debug;
import edu.iastate.utils.gui.GUIUtils;
import edu.iastate.utils.io.FileUtils;
import edu.iastate.utils.lang.MessageHandler;
import edu.iastate.utils.lang.MessageMap;
import edu.iastate.utils.sql.LocalDBConnection;

/**
 * Animal Trait Ontology Editor
 * @author Jie Bao
 * @since 2005-04-20
 */
public class ATOEditor
    extends ATOEditorGUI implements MessageHandler
{
    public ATOEditor()
    {
        super();
        try
        {
            jbInit();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    public static LocalDBConnection getConnection()
    {
        Preferences prefs = Preferences.userNodeForPackage(SettingPanel.class);
        LocalDBConnection ds = new LocalDBConnection();

        ds.setUrl(prefs.get("url",  "jdbc:postgresql://boole.cs.iastate.edu/ato"));
        ds.setUser(prefs.get("user", "ato"));
        ds.setPassword(prefs.get("passwd", "ato"));
        ds.setDriver(prefs.get("driver", "org.postgresql.Driver"));

        return ds;
    }

    public static void main(String[] args)
    {
        ATOEditor atoeditor = new ATOEditor();

        atoeditor.mainFrame.getContentPane().add(atoeditor);
        atoeditor.mainFrame.setSize(800, 600);
        atoeditor.jSplitPane1.setDividerLocation(500);
        atoeditor.mainFrame.setTitle("Animal Trait Ontology Editor");
        atoeditor.mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        atoeditor.mainFrame.setVisible(true);
    }

    private void jbInit() throws Exception
    {
        messageMap();

        if (!conn.connect())
        {
            Debug.trace("Cannot connect to the server");
        }
        else
        {
            tree2db = new Tree2ATO(conn.db);
            tree2db.deleteUndeclaredChildren = false;

            db2tree = new ATO2Tree(conn.db);
            avh = new AtoOntology("ATO", db2tree);
            // build the tree
            //avh.getTreeAVH().setTop(db2tree.getTree(null, -1).getTop());
            loadOntology();
            avh.getTreeAVH().setEnableDragDrop(false);

            paneTree.getViewport().add(avh.getEditorPane());

            ATOTreeEditor editor = (ATOTreeEditor) avh.getAVHEditor();
            editor.fatherPanel = this;
            editor.setEnableRename(false);
            editor.setEnableInsertParent(false);
            editor.setEnableDeleteButKeepChildren(false);
        }
    }

    // 2005-04-24
    synchronized void loadOntology()
    {
        Thread t = new Thread()
        {
            public void run()
            {
                int pb = statusBar.addProgressBar(true, 0, 0);
                statusBar.updateProgressBar(pb, "Load ATO...");
                btnReload.setEnabled(false);

                try
                {
                    TypedTree ato = db2tree.getTree(null, 1);
                    avh.getTreeAVH().setTop(ato.getTop());
                    avh.modified = false;
                    avh.getAVHEditor().history.clear();

                }
                catch (Exception ex)
                {
                }
                btnReload.setEnabled(true);
                statusBar.removeProgressBar(pb);

            }
        };
        t.start();

    }

    LocalDBConnection conn = ATOEditor.getConnection();
    static ATO2Tree db2tree;
    static Tree2ATO tree2db;
    AtoOntology avh;

    public void messageMap()
    {
        try
        {
            MessageMap.mapAction(this.btnUndo, this, "onUndo");
            MessageMap.mapAction(this.menuUndo, this, "onUndo");
            MessageMap.mapAction(this.btnRedo, this, "onRedo");
            MessageMap.mapAction(this.menuRedo, this, "onRedo");
            MessageMap.mapAction(this.btnConfig, this, "onConfig");
            MessageMap.mapAction(this.btnSubmit, this, "onSubmit");
            MessageMap.mapAction(this.btnAbout, this, "onAbout");
            MessageMap.mapAction(this.menuAbout, this, "onAbout");
            MessageMap.mapAction(this.btnExpand, this, "onExpand");
            MessageMap.mapAction(this.menuExpand, this, "onExpand");
            MessageMap.mapAction(this.menuExpandAll, this, "onExpandAll");
            MessageMap.mapAction(this.btnHelp, this, "onHelp");
            MessageMap.mapAction(this.menuHelp, this, "onHelp");
            MessageMap.mapAction(this.btnReload, this, "onReload");
            MessageMap.mapAction(this.btnFind, this, "onFind");
            MessageMap.mapAction(this.menuFind, this, "onFind");
            MessageMap.mapAction(this.menuFindNext, this, "onFindNext");

            mainFrame.addWindowListener(new WindowAdapter()
            {
                public void windowClosing(WindowEvent evt)
                {
                    onExit();
                }
            });
        }
        catch (Exception ex)
        {
        }
    }

    String searchTerm = null;
    Enumeration enumSearch = null;

    public void onFindNext(ActionEvent ae)
    {
        if (searchTerm == null)
        {
            String newTerm = JOptionPane.showInputDialog(
                "Search node on the ontology", searchTerm);
            if (newTerm == null)
            {
                return;
            }
            searchTerm = newTerm;
        }
        find();
    }

    // 2005-04-24
    public void onFind(ActionEvent ae)
    {
        String newTerm = JOptionPane.showInputDialog(
            "Search node on the ontology", searchTerm);
        if (newTerm == null)
        {
            return;
        }
        searchTerm = newTerm;

        find();

    }

    private void find()
    {
        TypedTree tree = avh.getTreeAVH();
        if (enumSearch == null || !enumSearch.hasMoreElements())
        {
            ATOTreeNode root = (ATOTreeNode) tree.getModel().getRoot();
            enumSearch = root.preorderEnumeration();
        }
        while (enumSearch.hasMoreElements())
        {
            ATOTreeNode node = (ATOTreeNode) enumSearch.nextElement();
            if (node.getComment() != null)
            {
                if (node.getComment().toString().indexOf(searchTerm) >= 0)
                {
                    tree.expandNode(node);
                    tree.setSelectionPath(tree.getPath(node));
                    return;
                }
            }
            if (node.getUserObject() != null)
            {
                if (node.getUserObject().equals(searchTerm))
                {
                    tree.expandNode(node);
                    tree.setSelectionPath(tree.getPath(node));
                    return;
                }
            }

        }
    }

    // 2005-04-24
    public void onReload(ActionEvent e)
    {
        loadOntology();
    }

    // 2005-04-23
    public void onExpand(ActionEvent e)
    {
        ATOTreeNode node = (ATOTreeNode) avh.getTreeAVH().getSelectedNode();
        if (node != null && node.status != ATOTreeNode.DELETED)
        {
            ATOTreeEditor editor = (ATOTreeEditor) avh.getAVHEditor();
            editor.addOneLevel(node);
        }
    }

    public void onExpandAll(ActionEvent e)
    {

        final ATOTreeNode node = (ATOTreeNode) avh.getTreeAVH().getSelectedNode();
        if (node != null && node.status != ATOTreeNode.DELETED)
        {
            Thread t = new Thread()
            {
                public void run()
                {
                    int pb = statusBar.addProgressBar(true, 0, 0);
                    statusBar.updateProgressBar(pb,
                                                "Full Expand " + node + "...");
                    btnReload.setEnabled(false);

                    try
                    {
                        ATOTreeEditor editor = (ATOTreeEditor) avh.getAVHEditor();
                        editor.addAllLevel(node);
                    }
                    catch (Exception ex)
                    {
                    }
                    btnReload.setEnabled(true);
                    statusBar.removeProgressBar(pb);

                }
            };
            t.start();
        }
    }

    /**
     * @since 2005-04-24
     * @param e ActionEvent
     */
    public void onHelp(ActionEvent e)
    {
        JLabel hog = new JLabel(this.hogIcon);
        JDialog dlg = new JDialog(this.mainFrame, true);
        dlg.getContentPane().setLayout(new BorderLayout());
        dlg.getContentPane().add(hog, BorderLayout.NORTH);

        JEditorPane editorPane = new JEditorPane();
        editorPane.setEditable(false);
        editorPane.setContentType("text/html");

        String info = "Animal Trait Ontology Editor<br>Jie Bao, Apr 2005";
        try
        {
            info = FileUtils.readFile("atohelp.html");
        }
        catch (IOException ex)
        {
        }

        editorPane.setText(info);
//        editorPane.scrollToReference("Animal");
        JScrollPane jsp = new JScrollPane(editorPane);
        dlg.getContentPane().add(jsp, BorderLayout.CENTER);
        dlg.setTitle("Help on ATO Editor");
        dlg.setSize(400, 400);
        GUIUtils.centerWithinScreen(dlg);
        dlg.setVisible(true);
    }

    /**
     * @since 2005-04-22
     * @param e ActionEvent
     */
    public void onAbout(ActionEvent e)
    {

        String infoAbout = "<html>" +
            "<font color=\"#FF0099\"><b>" +
            "Animal Trait Ontology Eidtor</b></font><br>Version " + 1.0 +
            "<br>" + "<br><b>Jie Bao</b><br>Apr 2005<br>" +
            "Iowa State University<br><a href=\"mailto:baojie@iastate.edu\">" +
            "baojie@iastate.edu</a><br><a href=\"http://www.cs.iastate.edu/~baojie\">" +
            "http://www.cs.iastate.edu/~baojie</a><br>" +
            "</html>";

        AboutBoxDialog dlg = new AboutBoxDialog(infoAbout, "About ATO Editor");
        dlg.showAboutBox();

    }

    /**
     * @since 2005-04-22
     */
    public void onExit()
    {
        // prompt for save
        if (avh != null && avh.modified)
        {
            int answer = JOptionPane.showConfirmDialog(this,
                "Do you want to update the database with the changes you have made? ");
            if (answer == JOptionPane.YES_OPTION)
            {
                onSubmit(null);
            }
        }
        conn.disconnect();

        setVisible(false);
        System.exit(0);
    }

    public void onConfig(ActionEvent e)
    {
        SettingPanel p = new SettingPanel();
        JDialog dlg = new JDialog(GUIUtils.getRootFrame(this));
        dlg.getContentPane().add(p);
        dlg.setTitle("JDBC Setting");
        dlg.setSize(400, 250);
        dlg.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        GUIUtils.centerWithinParent(dlg);

        dlg.setVisible(true);
    }

    /**
     * @since 2005-04-20
     * @param e ActionEvent
     */
    public void onUndo(ActionEvent e)
    {
        AVHEditor editor = avh.getAVHEditor();
        editor.undo();

    }

    /**
     * @since 2005-04-20
     * @param e ActionEvent
     */
    public void onRedo(ActionEvent e)
    {
        AVHEditor editor = avh.getAVHEditor();
        editor.redo();
    }

    /**
     * Submit changes to the database
     *
     * @since 2005-04-20
     * @param e ActionEvent
     */
    public void onSubmit(ActionEvent e)
    {
        TypedTree tree = avh.getTreeAVH();
        tree2db.saveTree(tree);

        // remove all delete node
        avh.purgeDeleted();

        avh.modified = false;
        avh.getAVHEditor().history.clear();
    }
}
