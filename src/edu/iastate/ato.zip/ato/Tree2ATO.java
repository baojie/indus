package edu.iastate.ato;

import java.sql.Connection;

import edu.iastate.anthill.indus.iterator.Tree2DB;
import java.util.Map;
import edu.iastate.utils.sql.JDBCUtils;
import java.util.HashMap;
import edu.iastate.anthill.indus.tree.TypedNode;
import java.util.Enumeration;
import edu.iastate.anthill.indus.tree.TypedTree;

/**
 * Save a tree to a database
 *
 * @author Jie Bao
 * @since 2005-04-22
 */
public class Tree2ATO
    extends Tree2DB
{
    public Tree2ATO(Connection db)
    {
        super(db);
    }

    protected void saveNode(TypedNode node)
    {
        ATOTreeNode atoNode = (ATOTreeNode) node;
        String id = node.getUserObject().toString();

        if (atoNode.status == ATOTreeNode.MODIFIED)
        {
            Object comment = node.getComment();

            Map field_value = new HashMap();
            field_value.put("id", id);
            field_value.put("name", comment);
            field_value.put("domain", AtoOntology.getDomainStr(node.getType()));

            JDBCUtils.insertOrUpdateDatabase(db, "term", field_value, "id");

            TypedNode parent = (TypedNode) node.getParent();
            if (parent != null)
            {
                String parentId = parent.getUserObject().toString();
                saveRelation(id, parentId, "isa");
            }

            atoNode.status = ATOTreeNode.UNMODIFIED;
        }
        else if (atoNode.status == ATOTreeNode.DELETED)
        {
            deleteNode(id);
            deleteParent(id);
        }
    }

    protected void saveRelation(String id, String parentId, String relation)
    {
        this.defaultSaveRelation("relation", "id", id, "pid", parentId, null, null);
    }

    protected void deleteChildren(String id)
    {
        this.defaultDeleteChildren("relation", "pid", id, null, null);
    }

    protected void deleteParent(String id)
    {
        this.defaultDeleteParent("relation", "id", id, null, null);
    }

    public void saveTree(TypedTree tree)
    {
        Enumeration en = tree.getTop().breadthFirstEnumeration();
        while (en.hasMoreElements())
        {
            TypedNode node = (TypedNode) en.nextElement();
            saveNode(node);
        }
    }

    /*  CREATE TABLE trait
       (
        trait_id varchar(32),
        trait_name varchar(256),
        abbreviat varchar(32),
        custom_name varchar(256),
        trait_desc varchar(256),
        measurement varchar(32),
        scale_unit varchar(32),
        CONSTRAINT trait_pkey PRIMARY KEY (trait_id)
       )*/

    public void saveTrait(Trait trait)
    {
        Map<String, String> field_value = new HashMap();
        field_value.put("trait_id", trait.id);
        field_value.put("trait_name", trait.name);
        field_value.put("abbreviat", trait.abbr);
        field_value.put("custom_name", trait.customName);
        field_value.put("trait_desc", trait.traitDesc);
        field_value.put("measurement", trait.measurement);
        field_value.put("scale_unit", trait.scaleUnit);

        boolean suc = JDBCUtils.insertOrUpdateDatabase(db, "trait", field_value,
            "trait_id");
        //System.out.println("saveTrait: " + suc);
    }

    protected void deleteNode(String id)
    {
        defaultDeleteNode("term", "id", id);
    }

}
