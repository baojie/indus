package edu.iastate.ato;

/*  CREATE TABLE trait
  (
   trait_id varchar(32),
   trait_name varchar(256),
   abbreviat varchar(32),
   custom_name varchar(256),
   trait_desc varchar(256),
   measurement varchar(32),
   scale_unit varchar(32),
   CONSTRAINT trait_pkey PRIMARY KEY (trait_id)
  )*/
 public class Trait
 {
     String id;
     String name;
     String abbr;
     String customName;
     String traitDesc;
     String measurement;
     String scaleUnit;
 }
