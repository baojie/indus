// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 6/15/2006 11:54:15 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ZLockTable.java

package Zql;

import java.util.Vector;

// Referenced classes of package Zql:
//            ZStatement

public class ZLockTable
    implements ZStatement
{

    public ZLockTable()
    {
        nowait_ = false;
        lockMode_ = null;
        tables_ = null;
    }

    public void addTables(Vector vector)
    {
        tables_ = vector;
    }

    public Vector getTables()
    {
        return tables_;
    }

    public void setLockMode(String s)
    {
        lockMode_ = new String(s);
    }

    public String getLockMode()
    {
        return lockMode_;
    }

    public boolean isNowait()
    {
        return nowait_;
    }

    boolean nowait_;
    String lockMode_;
    Vector tables_;
}