// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 6/15/2006 11:54:15 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ZOrderBy.java

package Zql;

import java.io.Serializable;

// Referenced classes of package Zql:
//            ZExp

public class ZOrderBy
    implements Serializable
{

    public ZOrderBy(ZExp zexp)
    {
        asc_ = true;
        exp_ = zexp;
    }

    public void setAscOrder(boolean flag)
    {
        asc_ = flag;
    }

    public boolean getAscOrder()
    {
        return asc_;
    }

    public ZExp getExpression()
    {
        return exp_;
    }

    public String toString()
    {
        return exp_.toString() + " " + (asc_ ? "ASC" : "DESC");
    }

    ZExp exp_;
    boolean asc_;
}