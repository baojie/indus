// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 6/15/2006 11:54:14 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ZInsert.java

package Zql;

import java.util.Vector;

// Referenced classes of package Zql:
//            ZExpression, ZQuery, ZStatement, ZExp

public class ZInsert
    implements ZStatement
{

    public ZInsert(String s)
    {
        columns_ = null;
        valueSpec_ = null;
        table_ = new String(s);
    }

    public String getTable()
    {
        return table_;
    }

    public Vector getColumns()
    {
        return columns_;
    }

    public void addColumns(Vector vector)
    {
        columns_ = vector;
    }

    public void addValueSpec(ZExp zexp)
    {
        valueSpec_ = zexp;
    }

    public Vector getValues()
    {
        if(!(valueSpec_ instanceof ZExpression))
            return null;
        else
            return ((ZExpression)valueSpec_).getOperands();
    }

    public ZQuery getQuery()
    {
        if(!(valueSpec_ instanceof ZQuery))
            return null;
        else
            return (ZQuery)valueSpec_;
    }

    public String toString()
    {
        StringBuffer stringbuffer = new StringBuffer("insert into " + table_);
        if(columns_ != null && columns_.size() > 0)
        {
            stringbuffer.append("(" + columns_.elementAt(0));
            for(int i = 1; i < columns_.size(); i++)
                stringbuffer.append("," + columns_.elementAt(i));

            stringbuffer.append(")");
        }
        String s = valueSpec_.toString();
        stringbuffer.append(" ");
        if(getValues() != null)
            stringbuffer.append("values ");
        if(s.startsWith("("))
            stringbuffer.append(s);
        else
            stringbuffer.append(" (" + s + ")");
        return stringbuffer.toString();
    }

    String table_;
    Vector columns_;
    ZExp valueSpec_;
}