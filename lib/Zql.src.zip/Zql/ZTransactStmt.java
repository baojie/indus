// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 6/15/2006 11:54:21 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ZTransactStmt.java

package Zql;


// Referenced classes of package Zql:
//            ZStatement

public class ZTransactStmt
    implements ZStatement
{

    public ZTransactStmt(String s)
    {
        comment_ = null;
        readOnly_ = false;
        statement_ = new String(s);
    }

    public void setComment(String s)
    {
        comment_ = new String(s);
    }

    public String getComment()
    {
        return comment_;
    }

    public boolean isReadOnly()
    {
        return readOnly_;
    }

    String statement_;
    String comment_;
    boolean readOnly_;
}