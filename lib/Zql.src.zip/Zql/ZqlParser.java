// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 6/15/2006 11:54:19 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ZqlParser.java

package Zql;

import java.io.*;
import java.util.Vector;

// Referenced classes of package Zql:
//            ZqlJJParser, ParseException, ZUtils, ZStatement, 
//            ZExp

public class ZqlParser
{

    public static void main(String args[])
        throws ParseException
    {
        ZqlParser zqlparser = null;
        if(args.length < 1)
        {
            System.out.println("/* Reading from stdin (exit; to finish) */");
            zqlparser = new ZqlParser(System.in);
        } else
        {
            try
            {
                zqlparser = new ZqlParser(new DataInputStream(new FileInputStream(args[0])));
            }
            catch(FileNotFoundException filenotfoundexception)
            {
                System.out.println("/* File " + args[0] + " not found. Reading from stdin */");
                zqlparser = new ZqlParser(System.in);
            }
        }
        if(args.length > 0)
            System.out.println("/* Reading from " + args[0] + "*/");
        for(ZStatement zstatement = null; (zstatement = zqlparser.readStatement()) != null;)
            System.out.println(zstatement.toString() + ";");

        System.out.println("exit;");
        System.out.println("/* Parse Successful */");
    }

    public ZqlParser(InputStream inputstream)
    {
        _parser = null;
        initParser(inputstream);
    }

    public ZqlParser()
    {
        _parser = null;
    }

    public void initParser(InputStream inputstream)
    {
        if(_parser == null)
            _parser = new ZqlJJParser(inputstream);
        else
            _parser.ReInit(inputstream);
    }

    public void addCustomFunction(String s, int i)
    {
        ZUtils.addCustomFunction(s, i);
    }

    public ZStatement readStatement()
        throws ParseException
    {
        if(_parser == null)
            throw new ParseException("Parser not initialized: use initParser(InputStream);");
        else
            return _parser.SQLStatement();
    }

    public Vector readStatements()
        throws ParseException
    {
        if(_parser == null)
            throw new ParseException("Parser not initialized: use initParser(InputStream);");
        else
            return _parser.SQLStatements();
    }

    public ZExp readExpression()
        throws ParseException
    {
        if(_parser == null)
            throw new ParseException("Parser not initialized: use initParser(InputStream);");
        else
            return _parser.SQLExpression();
    }

    ZqlJJParser _parser;
}