// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 6/15/2006 11:54:10 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ZConstant.java

package Zql;


// Referenced classes of package Zql:
//            ZExp

public class ZConstant
    implements ZExp
{

    public ZConstant(String s, int i)
    {
        type_ = -1;
        val_ = null;
        val_ = new String(s);
        type_ = i;
    }

    public String getValue()
    {
        return val_;
    }

    public int getType()
    {
        return type_;
    }

    public String toString()
    {
        if(type_ == 3)
            return '\'' + val_ + '\'';
        else
            return val_;
    }

    public static final int UNKNOWN = -1;
    public static final int COLUMNNAME = 0;
    public static final int NULL = 1;
    public static final int NUMBER = 2;
    public static final int STRING = 3;
    int type_;
    String val_;
}