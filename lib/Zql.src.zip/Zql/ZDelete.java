// Decompiled by DJ v3.5.5.77 Copyright 2003 Atanas Neshkov  Date: 6/15/2006 11:54:11 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   ZDelete.java

package Zql;


// Referenced classes of package Zql:
//            ZStatement, ZExp

public class ZDelete
    implements ZStatement
{

    public ZDelete(String s)
    {
        where_ = null;
        table_ = new String(s);
    }

    public void addWhere(ZExp zexp)
    {
        where_ = zexp;
    }

    public String getTable()
    {
        return table_;
    }

    public ZExp getWhere()
    {
        return where_;
    }

    public String toString()
    {
        StringBuffer stringbuffer = new StringBuffer("delete ");
        if(where_ != null)
            stringbuffer.append("from ");
        stringbuffer.append(table_);
        if(where_ != null)
            stringbuffer.append(" where " + where_.toString());
        return stringbuffer.toString();
    }

    String table_;
    ZExp where_;
}